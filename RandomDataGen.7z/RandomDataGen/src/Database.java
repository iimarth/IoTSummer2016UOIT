import java.util.ArrayList;
import java.util.Random;

public class Database {
	private static Random randGen;
	private static int mRange = 20;
	private static int mNumOfPeople = 0;
	//List which contains a random number of persons
	private static ArrayList<Person> mPeopleList = null;
	private static Room mRoom;

	public static void main(String[] args) {
		
		mPeopleList = new ArrayList<Person>();
		mRoom = new Room(mPeopleList);
		
		//generate a random number of persons; 
		//could also be handed over by the arguments of main
		System.out.println("Generate set of people\n");
		
		//Random randGen = new Random();
		//mNumOfPeople = randGen.nextInt(mRange); //create an integer in the range 0..mRange		
		mNumOfPeople = 5;
		
		System.out.println("The amount of persons is " + mNumOfPeople);
		
		int countReadings = 0;
		System.out.println("reading " + countReadings);
		//fill arraylist with mNumOfPeople Person-objects
		for(int i = 0; i < mNumOfPeople; i++){
			Person person = new Person(mRoom);
			mPeopleList.add(person);
			System.out.println("bodytemperature of person " + i + " is " + person.GetBodyTemp());
		}
		System.out.println();
		
		for(;;){
			countReadings++;
			System.out.println("reading " + countReadings);
			int i = 0;
			double curBodyTemp = 0;
			for(Person curPerson: mPeopleList){
				curPerson.SetNewBodyTemp();
				System.out.println("bodytemperature of person " + i + " is " + curPerson.GetBodyTemp());
				i++;
			}
		
			try {
				System.out.println();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
