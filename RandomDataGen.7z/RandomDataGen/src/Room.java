import java.util.ArrayList;

public class Room {
	
	private static int RoomIdCounter = 1;
	
	private int mRoomId;
	private double mRoomtemperature;
	private ArrayList<Person> mPersons;

	
	public Room(ArrayList<Person> _persons) {
		mPersons = _persons;
		mRoomId = RoomIdCounter++;
		mRoomtemperature = (Math.random()*10) + 15;
	}
	
	public double getAvgTemp(){
		double avgTemp = 0.0;
		for(int i = 0; i < this.mPersons.size(); i++){
			avgTemp += this.mPersons.get(i).GetBodyTemp();
		}
		avgTemp = avgTemp/this.mPersons.size();
		return avgTemp;
	}
	
	//private boolean inBetween(double _var, double _max, double _min){
	//	return _min <= _var && _var <= _max;
	//}

	public boolean addPersons(ArrayList<Person> _personslist){
		if(_personslist.size() == 0){
			return false;
		}
		
		for(int i = 0; i < _personslist.size(); i++){
			mPersons.add(_personslist.get(i));
		}
		return true;
	}
	
	public boolean removePersons(int...params){
		for(int i:params){
			if(i >= this.mPersons.size())
				return false;
			this.mPersons.remove(i);
		}
		return true;
	}
	
	public double getRoomtemperature() {
		return mRoomtemperature;
	}
	

	public void setRoomtemperature(double _roomtemperature) {
		double avgTemp = getAvgTemp();
		
		if(avgTemp < mRoomtemperature){
			mRoomtemperature += Math.random(); //to get a double between 0 and 1;
		}
		else if(avgTemp > mRoomtemperature){
			mRoomtemperature -= Math.random(); //to get a double between 0 and 1;	
		}
		
		this.mRoomtemperature = _roomtemperature;
	}
	
}
