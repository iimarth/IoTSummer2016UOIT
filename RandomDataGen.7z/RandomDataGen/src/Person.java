//22 and 42   --> Bodytemperature(on surface)
//15 and 30   --> Roomtemperature

import java.util.Random;

public class Person {
	private final double mMin;
	private final double mMax;
	private double mBodyTemp;
	private Room mLocation;
	
	public Person(Room _room){
		//predefine constants 
		mMin = 22.0;
		mMax = 42.0;

		mBodyTemp = mMin + (mMax - mMin) * Math.random();
		
		mLocation = _room;
	}
	
	public Room getLocation() {
		return mLocation;
	}

	public void setLocation(Room _location) {
		this.mLocation = mLocation;
	}

	// set a new body temperature which can differ between 0 and 1
	public void SetNewBodyTemp(){
		//if the bodytemperature is below the roomtemperature, the bodytemperature will rise slightly
		if(mBodyTemp < mLocation.getRoomtemperature()){
			mBodyTemp += Math.random(); //to get a double between 0 and 1;
		}
		//if it is above, the bodytemperature will drop 
		else if(mBodyTemp > mLocation.getRoomtemperature()){
			mBodyTemp -= Math.random();
		}
		//else: it will keep the value
	}
	
	public double GetBodyTemp(){
		return mBodyTemp;
	}
}
